import React, { useState } from "react";
import { Calendar, Clock } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectOption } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";

const ScheduleAppointmentDialog = () => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    specialty: "",
    doctor: "",
    date: "",
    time: ""
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.specialty || !formData.doctor || !formData.date || !formData.time) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Consulta agendada",
      description: `Sua consulta com ${formData.doctor} foi agendada para ${formData.date} às ${formData.time}.`
    });
    
    setOpen(false);
    setFormData({
      specialty: "",
      doctor: "",
      date: "",
      time: ""
    });
  };

  const specialties = [
    "Cardiologia",
    "Dermatologia",
    "Neurologia",
    "Ortopedia",
    "Pediatria",
    "Psiquiatria",
    "Ginecologia",
    "Urologia",
    "Oftalmologia",
    "Endocrinologia",
    "Nutrição",
    "Fisioterapia"
  ];

  const doctorsBySpecialty = {
    "Cardiologia": ["Dr. Paulo Mendes", "Dra. Sofia Alves"],
    "Dermatologia": ["Dra. Fernanda Lima", "Dr. Ricardo Nunes"],
    "Neurologia": ["Dra. Ana Oliveira", "Dr. Marcos Pereira"],
    "Ortopedia": ["Dr. Roberto Santos", "Dra. Camila Rocha"],
    "Pediatria": ["Dr. Carlos Silva", "Dra. Joana Ferreira"],
    "Psiquiatria": ["Dra. Isabel Gomes", "Dr. Tiago Martins"],
    "Ginecologia": ["Dra. Laura Costa", "Dr. Pedro Almeida"],
    "Urologia": ["Dr. André Gomes", "Dra. Vanessa Dias"],
    "Oftalmologia": ["Dr. Rui Barros", "Dra. Carolina Pinto"],
    "Endocrinologia": ["Dra. Mariana Sousa", "Dr. Fábio Correia"],
    "Nutrição": ["Dra. Beatriz Lima", "Dr. João Antunes"],
    "Fisioterapia": ["Dr. Miguel Silva", "Dra. Clara Santos"]
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="schedule-button w-full">Agendar Consulta</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Agendar Nova Consulta</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="specialty">Especialidade</Label>
            <Select 
              id="specialty" 
              name="specialty" 
              value={formData.specialty} 
              onChange={handleChange}
            >
              <SelectOption value="" disabled>Selecione uma especialidade</SelectOption>
              {specialties.map(spec => (
                <SelectOption key={spec} value={spec}>{spec}</SelectOption>
              ))}
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="doctor">Médico</Label>
            <Select 
              id="doctor" 
              name="doctor" 
              value={formData.doctor} 
              onChange={handleChange}
              disabled={!formData.specialty}
            >
              <SelectOption value="" disabled>Selecione um médico</SelectOption>
              {formData.specialty && doctorsBySpecialty[formData.specialty] && doctorsBySpecialty[formData.specialty].map(doc => (
                <SelectOption key={doc} value={doc}>{doc}</SelectOption>
              ))}
            </Select>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Data</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                <input
                  id="date"
                  name="date"
                  type="date"
                  value={formData.date}
                  onChange={handleChange}
                  className="pl-10 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="time">Horário</Label>
              <div className="relative">
                <Clock className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                <input
                  id="time"
                  name="time"
                  type="time"
                  value={formData.time}
                  onChange={handleChange}
                  className="pl-10 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                />
              </div>
            </div>
          </div>
          
          <Button type="submit" className="w-full">Confirmar Agendamento</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ScheduleAppointmentDialog;