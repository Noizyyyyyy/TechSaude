import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { FileText, Pill, Download } from 'lucide-react';

const MedicalReportDialog = ({ isOpen, onOpenChange, reportData }) => {
  if (!reportData) return null;

  const { title, consultationNotes, exams, prescriptions, doctor, specialty, date, time } = reportData;

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl text-gray-700">{title || "Relatório Médico"}</DialogTitle>
          <DialogDescription>
            Consulta com {doctor} ({specialty}) em {date.day}/{date.month} às {time}.
          </DialogDescription>
        </DialogHeader>
        <div className="mt-4 space-y-6">
          <section>
            <h3 className="text-lg font-semibold text-gray-600 mb-2">Notas da Consulta</h3>
            <p className="text-sm text-gray-500 whitespace-pre-line">{consultationNotes}</p>
          </section>

          {exams && exams.length > 0 && (
            <section>
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Exames Realizados</h3>
              <ul className="space-y-2">
                {exams.map((exam, index) => (
                  <li key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                    <div className="flex items-center">
                      <FileText className="h-5 w-5 text-blue-500 mr-3" />
                      <span className="text-sm text-gray-700">{exam.name}</span>
                    </div>
                    <Button variant="ghost" size="sm" asChild>
                      <a href={exam.url} target="_blank" rel="noopener noreferrer">
                        <Download className="h-4 w-4 mr-1" /> Ver
                      </a>
                    </Button>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {prescriptions && prescriptions.length > 0 && (
            <section>
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Prescrições</h3>
              <ul className="space-y-2">
                {prescriptions.map((prescription, index) => (
                  <li key={index} className="flex items-start p-3 bg-gray-50 rounded-md">
                    <Pill className="h-5 w-5 text-green-500 mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-gray-700">{prescription.name}</p>
                      <p className="text-xs text-gray-500">{prescription.dosage}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
        <div className="mt-6 flex justify-end">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Fechar</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default MedicalReportDialog;
