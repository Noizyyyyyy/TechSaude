import React from 'react';
import { Heart } from 'lucide-react';

const AppHeader = ({ userName }) => {
  return (
    <header className="app-header">
      <div className="flex items-center mb-4">
        <Heart className="h-6 w-6 text-gray-400 mr-2" />
        <span className="text-gray-400 text-xl font-medium">Tech Saúde</span>
      </div>
      <h1 className="text-2xl text-gray-600 font-medium">Olá, {userName}</h1>
    </header>
  );
};

export default AppHeader;
