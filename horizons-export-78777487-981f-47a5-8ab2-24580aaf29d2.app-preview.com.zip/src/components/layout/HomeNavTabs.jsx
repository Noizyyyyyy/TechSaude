import React from 'react';
import { Stethoscope, Calendar, User } from 'lucide-react';
import { motion } from 'framer-motion';

const HomeNavTabs = ({ activeTab, setActiveTab }) => {
  const tabItems = [
    { id: "specialties", label: "Especialidades", icon: Stethoscope },
    { id: "appointments", label: "Agendamentos", icon: Calendar },
    { id: "profile", label: "Perfil", icon: User },
  ];
  
  return (
    <div className="nav-tabs">
      {tabItems.map(item => (
        <motion.button
          key={item.id}
          className={`nav-tab ${activeTab === item.id ? "text-gray-700 font-semibold" : "text-gray-500"}`}
          onClick={() => setActiveTab(item.id)}
          whileTap={{ scale: 0.95 }}
        >
          <div className={`p-2 rounded-full mb-1 ${activeTab === item.id ? "bg-gray-300" : "bg-gray-200"}`}>
            <item.icon className={`h-5 w-5 ${activeTab === item.id ? "text-gray-700" : "text-gray-500"}`} />
          </div>
          <span>{item.label}</span>
        </motion.button>
      ))}
    </div>
  );
};

export default HomeNavTabs;
