import React from 'react';
import { Home, Calendar, User } from 'lucide-react';
import { motion } from 'framer-motion';

const AppFooter = ({ activeTab, setActiveTab }) => {
  const navItems = [
    { id: "home", label: "Home", icon: Home },
    { id: "appointments", label: "Consultas", icon: Calendar },
    { id: "profile", label: "Perfil", icon: User },
  ];

  return (
    <footer className="app-footer">
      {navItems.map(item => (
        <motion.div
          key={item.id}
          className={`footer-icon ${activeTab === item.id ? "text-gray-700" : "text-gray-500"}`}
          onClick={() => setActiveTab(item.id)}
          whileTap={{ scale: 0.9 }}
        >
          <item.icon className={`h-6 w-6 ${activeTab === item.id ? "text-gray-700" : "text-gray-500"}`} />
          <span className={activeTab === item.id ? "font-semibold" : ""}>{item.label}</span>
        </motion.div>
      ))}
    </footer>
  );
};

export default AppFooter;
