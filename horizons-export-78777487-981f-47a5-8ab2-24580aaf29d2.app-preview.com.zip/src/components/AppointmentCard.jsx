import React from "react";
import { Calendar, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";

const AppointmentCard = ({ appointment, onViewReport }) => {
  const { date, doctor, specialty, time, report } = appointment;

  return (
    <div className="appointment-card flex flex-col sm:flex-row items-start sm:items-center mb-3">
      <div className="flex items-center w-full sm:w-auto">
        <div className="flex-shrink-0 mr-4 bg-gray-200 rounded-lg p-2 flex items-center justify-center">
          <Calendar className="text-gray-500 h-6 w-6" />
          <div className="ml-1 text-center">
            <div className="text-sm font-bold">{date.day}</div>
            <div className="text-xs uppercase">{date.month}</div>
          </div>
        </div>
        <div className="flex-grow">
          <h3 className="text-gray-700 font-medium">{doctor}</h3>
          <p className="text-gray-500 text-sm">{specialty}</p>
          <p className="text-gray-500 text-sm">{time}</p>
        </div>
      </div>
      {report && (
        <Button 
          variant="outline" 
          size="sm" 
          onClick={onViewReport} 
          className="mt-2 sm:mt-0 sm:ml-auto w-full sm:w-auto"
        >
          <FileText className="mr-2 h-4 w-4" /> Ver Relatório
        </Button>
      )}
    </div>
  );
};

export default AppointmentCard;
