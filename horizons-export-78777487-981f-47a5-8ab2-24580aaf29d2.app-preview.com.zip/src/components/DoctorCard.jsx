
import React from "react";
import { Star } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const DoctorCard = ({ name, specialty, rating }) => {
  return (
    <div className="doctor-card">
      <Avatar className="doctor-avatar">
        <AvatarFallback className="bg-gray-300 text-gray-600">
          {name.split(" ").map(n => n[0]).join("")}
        </AvatarFallback>
      </Avatar>
      <div>
        <h3 className="text-gray-700 font-medium">{name}</h3>
        <p className="text-gray-500 text-sm">{specialty}</p>
        <div className="rating">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`h-3 w-3 ${i < Math.floor(rating) ? "fill-amber-400 text-amber-400" : "text-gray-300"}`}
              />
            ))}
          </div>
          <span className="text-xs ml-1 text-gray-600">{rating}</span>
        </div>
      </div>
    </div>
  );
};

export default DoctorCard;
