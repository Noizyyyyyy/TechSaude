import React from 'react';
import { motion } from 'framer-motion';
import { Search } from 'lucide-react';
import AppointmentCard from '@/components/AppointmentCard';
import DoctorCard from '@/components/DoctorCard';
import HomeNavTabs from '@/components/layout/HomeNavTabs';

const HomePage = ({
  upcomingAppointments,
  recommendedDoctors,
  searchQuery,
  handleSearch,
  activeTab,
  setActiveTab,
  onViewReport
}) => {
  const filteredDoctors = recommendedDoctors.filter(doctor =>
    doctor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doctor.specialty.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <>
      <section className="mt-6">
        <h2 className="text-gray-600 text-lg font-medium mb-2">Próximas Consultas</h2>
        {upcomingAppointments.slice(0, 1).map(appointment => (
          <motion.div
            key={appointment.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <AppointmentCard
              appointment={appointment}
              onViewReport={() => onViewReport(appointment)}
            />
          </motion.div>
        ))}
      </section>

      <div className="search-bar">
        <Search className="h-5 w-5 text-gray-400 mr-2" />
        <input
          type="text"
          placeholder="Pesquisar médicos ou especialidades"
          className="bg-transparent border-none outline-none flex-grow text-gray-600 text-sm"
          value={searchQuery}
          onChange={handleSearch}
        />
      </div>
      
      <HomeNavTabs activeTab={activeTab} setActiveTab={setActiveTab} />

      <section className="mt-6">
        <h2 className="text-gray-600 text-lg font-medium mb-2">Médicos Recomendados</h2>
        {filteredDoctors.length > 0 ? (
          filteredDoctors.map(doctor => (
            <motion.div
              key={doctor.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: doctor.id * 0.05 }}
            >
              <DoctorCard
                name={doctor.name}
                specialty={doctor.specialty}
                rating={doctor.rating}
              />
            </motion.div>
          ))
        ) : (
          <p className="text-gray-500 text-sm">Nenhum médico encontrado</p>
        )}
      </section>
    </>
  );
};

export default HomePage;
