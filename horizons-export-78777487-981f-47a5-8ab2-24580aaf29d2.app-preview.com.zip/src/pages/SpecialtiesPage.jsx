import React from 'react';
import { motion } from 'framer-motion';
import { Search } from 'lucide-react';

const SpecialtiesPage = ({ specialties, searchQuery, handleSearch }) => {
  const filteredSpecialties = specialties.filter(spec =>
    spec.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="mt-4"
    >
      <div className="search-bar mb-4">
        <Search className="h-5 w-5 text-gray-400 mr-2" />
        <input
          type="text"
          placeholder="Pesquisar especialidades"
          className="bg-transparent border-none outline-none flex-grow text-gray-600 text-sm"
          value={searchQuery}
          onChange={handleSearch}
        />
      </div>
      <h2 className="text-gray-600 text-lg font-medium mb-3">Todas as Especialidades</h2>
      {filteredSpecialties.length > 0 ? (
        <div className="grid grid-cols-2 gap-3">
          {filteredSpecialties.map(spec => (
            <motion.div
              key={spec}
              className="bg-gray-100 p-4 rounded-lg text-center text-gray-700 font-medium hover:bg-gray-200 cursor-pointer transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {spec}
            </motion.div>
          ))}
        </div>
      ) : (
        <p className="text-gray-500 text-sm">Nenhuma especialidade encontrada.</p>
      )}
    </motion.div>
  );
};

export default SpecialtiesPage;
