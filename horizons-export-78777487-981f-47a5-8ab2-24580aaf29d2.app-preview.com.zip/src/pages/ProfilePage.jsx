import React from 'react';
import { motion } from 'framer-motion';
import { User, ListChecks, Settings } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const ProfilePage = () => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.3 }}
    className="mt-4 text-center"
  >
    <Avatar className="mx-auto h-24 w-24 mb-4">
      <AvatarImage src="https://github.com/shadcn.png" alt="Clovis" />
      <AvatarFallback>CL</AvatarFallback>
    </Avatar>
    <h2 className="text-xl text-gray-700 font-semibold">Clovis Silva</h2>
    <p className="text-gray-500 text-sm">clovis.silva@email.com</p>
    <div className="mt-6 space-y-3">
      <Button variant="outline" className="w-full justify-start">
        <User className="mr-2 h-4 w-4" /> Informações Pessoais
      </Button>
      <Button variant="outline" className="w-full justify-start">
        <ListChecks className="mr-2 h-4 w-4" /> Histórico de Consultas
      </Button>
      <Button variant="outline" className="w-full justify-start">
        <Settings className="mr-2 h-4 w-4" /> Configurações
      </Button>
      <Button variant="destructive" className="w-full justify-start mt-4">
        Sair
      </Button>
    </div>
  </motion.div>
);

export default ProfilePage;