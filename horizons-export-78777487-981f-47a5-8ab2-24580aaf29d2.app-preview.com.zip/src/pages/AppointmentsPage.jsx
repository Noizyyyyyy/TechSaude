import React from 'react';
import { motion } from 'framer-motion';
import AppointmentCard from '@/components/AppointmentCard';

const AppointmentsPage = ({ appointments, onViewReport }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.3 }}
    className="mt-4"
  >
    <h2 className="text-gray-600 text-lg font-medium mb-3">Meus Agendamentos</h2>
    {appointments.length > 0 ? (
      appointments.map(appointment => (
        <AppointmentCard
          key={appointment.id}
          appointment={appointment}
          onViewReport={() => onViewReport(appointment)}
        />
      ))
    ) : (
      <p className="text-gray-500 text-sm">Você não possui agendamentos.</p>
    )}
  </motion.div>
);

export default AppointmentsPage;
