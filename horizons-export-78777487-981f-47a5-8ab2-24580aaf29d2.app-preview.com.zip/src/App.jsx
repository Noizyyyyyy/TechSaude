import React, { useState } from "react";
import { AnimatePresence } from "framer-motion";
import { Toaster } from "@/components/ui/toaster";
import ScheduleAppointmentDialog from "@/components/ScheduleAppointmentDialog";
import MedicalReportDialog from "@/components/MedicalReportDialog"; 

import AppHeader from "@/components/layout/AppHeader";
import AppFooter from "@/components/layout/AppFooter";

import HomePage from "@/pages/HomePage";
import SpecialtiesPage from "@/pages/SpecialtiesPage";
import AppointmentsPage from "@/pages/AppointmentsPage";
import ProfilePage from "@/pages/ProfilePage";

const App = () => {
  const [activeTab, setActiveTab] = useState("home");
  const [searchQuery, setSearchQuery] = useState("");
  const [isReportDialogOpen, setIsReportDialogOpen] = useState(false);
  const [currentReportData, setCurrentReportData] = useState(null);

  const allAppointments = [
    {
      id: 1,
      doctor: "Dra. Fernanda Lima",
      specialty: "Dermatologia",
      time: "Sex, 14:00",
      date: { day: "25", month: "ABR" },
      report: {
        title: "Relatório Consulta Dermatologia - 25/04",
        consultationNotes: "Paciente apresentou queixa de pele seca e descamação no couro cabeludo. Foi diagnosticada dermatite seborreica.\nRecomendado uso de shampoo específico (Cetoconazol 2%) e hidratante corporal intensivo.\nRetorno em 30 dias para avaliação.",
        exams: [
          { name: "Exame Micológico Direto.pdf", url: "#", type: "pdf" },
          { name: "Hemograma Completo.pdf", url: "#", type: "pdf" }
        ],
        prescriptions: [
          { name: "Cetoconazol Shampoo 2%", dosage: "Aplicar no couro cabeludo 3x/semana" },
          { name: "Hidratante Ureia 10%", dosage: "Aplicar no corpo 2x/dia" }
        ]
      }
    },
    {
      id: 2,
      doctor: "Dr. Paulo Mendes",
      specialty: "Cardiologia",
      time: "Qua, 10:30",
      date: { day: "29", month: "ABR" },
      report: {
        title: "Relatório Consulta Cardiologia - 29/04",
        consultationNotes: "Check-up cardiológico de rotina. Pressão arterial 120/80 mmHg. ECG sem alterações significativas.\nRecomendado manter dieta equilibrada e atividade física regular.",
        exams: [
          { name: "Eletrocardiograma (ECG).pdf", url: "#", type: "pdf" },
          { name: "Perfil Lipídico.pdf", url: "#", type: "pdf" }
        ],
        prescriptions: [
          { name: "AAS 100mg", dosage: "1 comprimido ao dia, após almoço (preventivo)" },
        ]
      }
    }
  ];

  const recommendedDoctors = [
    { id: 1, name: "Dr. Paulo Mendes", specialty: "Cardiologia", rating: 4.8 },
    { id: 2, name: "Dra. Ana Oliveira", specialty: "Neurologia", rating: 4.7 },
    { id: 3, name: "Dr. Roberto Santos", specialty: "Ortopedia", rating: 4.5 },
    { id: 4, name: "Dra. Laura Costa", specialty: "Ginecologia", rating: 4.9 },
    { id: 5, name: "Dr. André Gomes", specialty: "Urologia", rating: 4.6 }
  ];

  const specialties = [
    "Cardiologia", "Dermatologia", "Neurologia", "Ortopedia", "Pediatria",
    "Psiquiatria", "Ginecologia", "Urologia", "Oftalmologia",
    "Endocrinologia", "Nutrição", "Fisioterapia"
  ];

  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleViewReport = (appointment) => {
    if (appointment.report) {
      setCurrentReportData({ ...appointment.report, doctor: appointment.doctor, specialty: appointment.specialty, date: appointment.date, time: appointment.time });
      setIsReportDialogOpen(true);
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case "home":
        return (
          <HomePage
            upcomingAppointments={allAppointments}
            recommendedDoctors={recommendedDoctors}
            searchQuery={searchQuery}
            handleSearch={handleSearch}
            activeTab={activeTab} 
            setActiveTab={setActiveTab}
            onViewReport={handleViewReport}
          />
        );
      case "specialties":
        return <SpecialtiesPage specialties={specialties} searchQuery={searchQuery} handleSearch={handleSearch} />;
      case "appointments":
        return <AppointmentsPage appointments={allAppointments} onViewReport={handleViewReport} />;
      case "profile":
        return <ProfilePage />;
      default:
        return null;
    }
  };

  return (
    <div className="phone-frame tech-saude-theme min-h-screen flex flex-col">
      <AppHeader userName="Clovis" />

      <main className="app-content flex-grow">
        <ScheduleAppointmentDialog />
        <AnimatePresence mode="wait">
          {renderContent()}
        </AnimatePresence>
      </main>

      <AppFooter activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <MedicalReportDialog 
        isOpen={isReportDialogOpen}
        onOpenChange={setIsReportDialogOpen}
        reportData={currentReportData}
      />
      <Toaster />
    </div>
  );
};

export default App;